from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session
import os
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 為了顯示flash訊息，需要設置一個密鑰

# 模擬的使用者資料庫
users = {
    "user1": {"password": "password1", "key": "key1"},
    "user2": {"password": "password2", "key": "key2"}
}

files = {
    "肝臟模型": "liver_model.txt",
    "乳癌ki67模型": "breast_cancer_ki67_model.txt",
    "肝纖維模型": "liver_fibrosis_model.txt",
    "油滴模型": "oil_drop_model.txt"
}

classes = {
    "肝臟影像": "liver_images",
    "乳癌ki67影像": "breast_cancer_ki67_images",
    "肝纖維影像": "liver_fibrosis_images",
    "油滴影像": "oil_drop_images"
}

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif','bmp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    key = request.form['key']
    if username in users and users[username]['password'] == password and users[username]['key'] == key:
        session['username'] = username
        session['key'] = key
        flash('登入成功')
        return redirect(url_for('main'))
    else:
        flash('帳號、密碼或金鑰匙錯誤')
        return redirect(url_for('home'))

@app.route('/main')
def main():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    return render_template('main.html', username=session['username'], key=session['key'])

@app.route('/download')
def download():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    return render_template('download.html', files=files, username=session['username'], key=session['key'])

@app.route('/download_file')
def download_file():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    filename = request.args.get('filename')
    if not filename:
        flash('未選擇文件')
        return redirect(url_for('download'))
    file_path = os.path.join('./static', 'model', filename)
    if os.path.exists(file_path):
        log_download(session['username'], session['key'], filename)
        return send_file(file_path, as_attachment=True)
    else:
        flash('文件不存在')
        return redirect(url_for('download'))

@app.route('/upload')
def upload():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    return render_template('upload.html', classes=classes, username=session['username'], key=session['key'])

@app.route('/upload_file', methods=['POST'])
def upload_file():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    if 'files' not in request.files or 'class' not in request.form:
        flash('沒有選擇文件或類別')
        return redirect(url_for('upload'))
    files = request.files.getlist('files')
    selected_class = request.form['class']
    if not files or files[0].filename == '':
        flash('沒有選擇文件')
        return redirect(url_for('upload'))
    upload_folder = os.path.join(app.root_path, 'uploads', session['username'], classes[selected_class])
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
    saved_files = []
    for file in files:
        if file and allowed_file(file.filename):
            filename = file.filename
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
            saved_files.append(filename)
    if saved_files:
        flash(f'文件上傳成功，共上傳 {len(saved_files)} 個文件')
        log_upload(session['username'], selected_class, saved_files)
        return redirect(url_for('upload'))
    else:
        flash('文件上傳失敗，僅允許上傳影像文件')
        return redirect(url_for('upload'))

@app.route('/download_log')
def download_log():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    with open('download_log.json', 'r', encoding='utf-8') as f:
        logs = json.load(f)
    return render_template('download_log.html', logs=logs, username=session['username'], key=session['key'])

def log_download(username, key, filename):
    log_entry = {
        "username": username,
        "key": key,
        "filename": filename,
        "timestamp": datetime.now().isoformat()
    }
    if os.path.exists('download_log.json'):
        with open('download_log.json', 'r', encoding='utf-8') as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(log_entry)
    with open('download_log.json', 'w', encoding='utf-8') as f:
        json.dump(logs, f, ensure_ascii=False, indent=4)

def log_upload(username, selected_class, filenames):
    log_entry = {
        "username": username,
        "class": selected_class,
        "file_count": len(filenames),
        "filenames": filenames,
        "timestamp": datetime.now().isoformat()
    }
    if os.path.exists('upload_log.json'):
        with open('upload_log.json', 'r', encoding='utf-8') as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(log_entry)
    with open('upload_log.json', 'w', encoding='utf-8') as f:
        json.dump(logs, f, ensure_ascii=False, indent=4)

@app.route('/logout')
def logout():
    session.clear()
    flash('您已登出')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
