from cryptography.fernet import Fernet

# 生成密鑰
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# 原始字符串
original_string = "200468803601495"

# 加密字符串
encrypted_string = cipher_suite.encrypt(original_string.encode())
print("加密後的字符串:", encrypted_string)

# 解密字符串
decrypted_string = cipher_suite.decrypt(encrypted_string).decode()
print("解密後的字符串:", decrypted_string)
