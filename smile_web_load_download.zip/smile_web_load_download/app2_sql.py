from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session
import os
import json
import mysql.connector
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'Q36111223'  # 為了顯示flash訊息，需要設置一個密鑰

# MySQL 連接設置
db_config = {
    'user': 'root',
    'password': '0000',
    'host': 'localhost',
    'database': 'harden_web_micor'
}

# 檢查文件是否允許上傳
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif','bmp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 讀取類別資料
def get_classes():
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("SELECT name, folder FROM classes")
    result = cursor.fetchall()
    cnx.close()
    return {name: folder for name, folder in result}

# 讀取文件資料
def get_files():
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("SELECT name, path FROM files")
    result = cursor.fetchall()
    cnx.close()
    return {name: path for name, path in result}

# 登錄頁面
@app.route('/')
def home():
    return render_template('login.html')

# 處理登錄請求
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    key = request.form['key']

    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s AND `key`=%s", (username, password, key))
    user = cursor.fetchone()
    cnx.close()

    if user:
        session['username'] = username
        session['key'] = key
        flash('登入成功')
        return redirect(url_for('main'))
    else:
        flash('帳號、密碼或金鑰匙錯誤')
        return redirect(url_for('home'))

# 功能選擇頁面
@app.route('/main')
def main():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    return render_template('main.html', username=session['username'], key=session['key'])

# 下載頁面
@app.route('/download')
def download():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    files = get_files()
    return render_template('download.html', files=files, username=session['username'], key=session['key'])

# 處理文件下載請求
@app.route('/download_file')
def download_file():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    filename = request.args.get('filename')
    if not filename:
        flash('未選擇文件')
        return redirect(url_for('download'))
    files = get_files()
    if filename in files:
        file_path = os.path.join('./static', 'model', files[filename])
        log_download(session['username'], session['key'], filename)
        return send_file(file_path, as_attachment=True)
    else:
        flash('文件不存在')
        return redirect(url_for('download'))

# 上傳頁面
@app.route('/upload')
def upload():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    classes = get_classes()
    return render_template('upload.html', classes=classes, username=session['username'], key=session['key'])

# 處理文件上傳請求
@app.route('/upload_file', methods=['POST'])
def upload_file():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    if 'files' not in request.files or 'class' not in request.form:
        flash('沒有選擇文件或類別')
        return redirect(url_for('upload'))
    files = request.files.getlist('files')
    selected_class = request.form['class']
    if not files or files[0].filename == '':
        flash('沒有選擇文件')
        return redirect(url_for('upload'))
    classes = get_classes()
    if selected_class not in classes:
        flash('選擇的類別無效')
        return redirect(url_for('upload'))
    upload_folder = os.path.join(app.root_path, 'uploads', session['username'], classes[selected_class])
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)
    saved_files = []
    for file in files:
        if file and allowed_file(file.filename):
            filename = file.filename
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
            saved_files.append(filename)
    if saved_files:
        flash(f'文件上傳成功，共上傳 {len(saved_files)} 個文件')
        log_upload(session['username'], selected_class, saved_files)
        return redirect(url_for('upload'))
    else:
        flash('文件上傳失敗，僅允許上傳影像文件')
        return redirect(url_for('upload'))

# 下載記錄頁面
@app.route('/download_log')
def download_log():
    if 'username' not in session:
        flash('請先登入')
        return redirect(url_for('home'))
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM download_logs")
    logs = cursor.fetchall()
    cnx.close()
    with open('download_log.json', 'r', encoding='utf-8') as f:
        logs = json.load(f)
    return render_template('download_log.html', logs=logs, username=session['username'], key=session['key'])

# 記錄下載日志
def log_download(username, key, filename):
    log_entry = {
        "username": username,
        "key": key,
        "filename": filename,
        "timestamp": datetime.now().isoformat()
    }
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("INSERT INTO download_logs (username, `key`, filename, timestamp) VALUES (%s, %s, %s, %s)",
                   (username, key, filename, log_entry['timestamp']))
    cnx.commit()
    cnx.close()
    if os.path.exists('download_log.json'):
        with open('download_log.json', 'r', encoding='utf-8') as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(log_entry)
    with open('download_log.json', 'w', encoding='utf-8') as f:
        json.dump(logs, f, ensure_ascii=False, indent=4)

# 記錄上傳日志
def log_upload(username, selected_class, filenames):
    log_entry = {
        "username": username,
        "class": selected_class,
        "file_count": len(filenames),
        "filenames": json.dumps(filenames),
        "timestamp": datetime.now().isoformat()
    }
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    cursor.execute("INSERT INTO upload_logs (username, class, file_count, filenames, timestamp) VALUES (%s, %s, %s, %s, %s)",
                   (username, selected_class, log_entry['file_count'], log_entry['filenames'], log_entry['timestamp']))
    cnx.commit()
    cnx.close()
    if os.path.exists('upload_log.json'):
        with open('upload_log.json', 'r', encoding='utf-8') as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(log_entry)
    with open('upload_log.json', 'w', encoding='utf-8') as f:
        json.dump(logs, f, ensure_ascii=False, indent=4)

# 登出
@app.route('/logout')
def logout():
    session.clear()
    flash('您已登出')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
